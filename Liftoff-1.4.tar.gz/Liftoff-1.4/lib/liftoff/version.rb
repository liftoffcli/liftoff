module Liftoff
  VERSION = '1.4'
end
