module Liftoff
  VERSION = '1.8.3'
end
