module Liftoff
  VERSION = '1.0'
end
