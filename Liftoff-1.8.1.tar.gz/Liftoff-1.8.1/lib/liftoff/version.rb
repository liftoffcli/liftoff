module Liftoff
  VERSION = '1.8.1'
end
