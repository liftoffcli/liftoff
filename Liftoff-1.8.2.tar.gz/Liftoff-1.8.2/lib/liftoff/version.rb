module Liftoff
  VERSION = '1.8.2'
end
