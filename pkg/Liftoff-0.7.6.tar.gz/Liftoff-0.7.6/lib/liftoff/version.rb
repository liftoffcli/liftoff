module Liftoff
  VERSION = '0.7.6'
end
