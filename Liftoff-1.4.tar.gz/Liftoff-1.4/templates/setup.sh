#!/usr/bin/env bash

bundle install
pod install
