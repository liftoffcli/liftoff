source 'https://rubygems.org'

gem 'cocoapods'
gem 'xcpretty'
