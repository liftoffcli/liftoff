module Liftoff
  VERSION = '1.8.0'
end
