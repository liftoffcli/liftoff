module Liftoff
  VERSION = '1.4.1'
end
