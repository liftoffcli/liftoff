module Liftoff
  VERSION = '1.2'
end
