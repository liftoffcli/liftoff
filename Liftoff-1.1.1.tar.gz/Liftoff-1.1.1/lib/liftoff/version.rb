module Liftoff
  VERSION = '1.1.1'
end
