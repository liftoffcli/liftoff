module Liftoff
  VERSION = '1.6.0'
end
