module Liftoff
  VERSION = '1.7.0'
end
